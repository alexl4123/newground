

class CDNLDataStructure:

    def __init__(self):

        self.bdg_literals = {}
        self.rule_dictionary = None
        self.graph_ds = None

        self.rewritten_to_original_dict = {}