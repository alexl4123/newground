

class ASPProgram:

    def get_string(self):
        return ""


    def add_string(self, to_add_prg):
        pass