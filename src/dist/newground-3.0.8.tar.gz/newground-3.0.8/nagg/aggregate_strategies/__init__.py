"""
Module responsible for helping to transform the aggregates.
"""
