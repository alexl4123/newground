"""
nagg helper module
"""
