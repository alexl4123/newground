"""
New foundedness part helper module.
"""