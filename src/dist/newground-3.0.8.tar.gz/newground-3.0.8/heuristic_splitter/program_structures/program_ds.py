

class ProgramDS:

    def __init__(self):

        self.maximum_variables_grounded_naively = 0

