

class AstLookupHelper:

    def __init__(self):

        self.rules = []

    def add_rule(self, rule):
        self.rules.append(rule)

    def get_rules(self):
        return self.rules



